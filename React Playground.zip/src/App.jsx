import React, { useState } from 'react';
import './style.css';
import Select from 'react-select';


export function App() {
  const [modalType, setModalType] = useState(null);
  const [customerName, setCustomerName] = useState('');
  const [productName, setProductName] = useState('');
  const [productBrand, setProductBrand] = useState('');
  const [product, setProduct] = useState('');
  const [pFrom, setPFrom] = useState('');
  const [pRate, setPRate] = useState('');
  const [pQty, setPQty] = useState('');
  const [pVehicle, setPVehicle] = useState('');
  const [toParty, setToParty] = useState(null);
  const [toRate, setToRate] = useState('');
  const [toQty, setToQty] = useState('');
  const [step, setStep] = useState("purchase"); // Tracks current step: "purchase" or "toParty"
  const [purchaseForm, setPurchaseForm] = useState({
    pFrom: "",
    pRate: "",
    pQty: "",
    pVehicle: "",
  }); // State for Purchase From Form
  const [toPartyEntries, setToPartyEntries] = useState([]); // List of "To Party" entries
   const [currentToParty, setCurrentToParty] = useState({
     selectedToParty: "",
     toRate: "",
     toQty: ""
     }); // State for the current "To Party" entry
   // State for handling product selection and form fields
   const [products, setProducts] = useState([]);  // List of products
   const [selectedProduct, setSelectedProduct] = useState(null);  // Selected product
   const [fromParties, setParties] = useState([]); // State for storing the parties list
   const [selectedFromParty, setSelectedFromParty] = useState(null); // State for selected party
   const [toParties, setToParties] = useState([]); // State for storing the parties list
   const [selectedToParty, setSelectedToParty] = useState(null); // State for selected party


   const fetchProducts = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/products', {
        method: 'GET',  // Method is GET by default, so it's optional here
        headers: {
          'Content-Type': 'application/json', // This is typically included for APIs that return JSON
        },
      });
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();  // Parsing the JSON data from the response
      setProducts(data);  // Set the product data in the state
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchPfCustomersList = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/pf/customers', {
        method: 'GET',  // Method is GET by default, so it's optional here
        headers: {
          'Content-Type': 'application/json', // This is typically included for APIs that return JSON
        },
      });
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();  // Parsing the JSON data from the response
      setParties(data);  // Set the product data in the state
    } catch (error) {
      console.error('Error fetching parties:', error);
    }
  };

  const fetchTpCustomersList = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/tp/customers', {
        method: 'GET',  // Method is GET by default, so it's optional here
        headers: {
          'Content-Type': 'application/json', // This is typically included for APIs that return JSON
        },
      });
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();  // Parsing the JSON data from the response
      setToParties(data);  // Set the toParty data in the state
    } catch (error) {
      console.error('Error fetching to parties:', error);
    }
  };

  const openModal = (type) => {
    setModalType(type);
    setStep("purchase");
    if (type === "Challan") {
      fetchProducts();  // Fetch products when opening Challan modal
      fetchPfCustomersList(); // Fetch pfPartyList when opening Challan modal
      fetchTpCustomersList();
    }
  };

  const closeModal = () => {
    setModalType(null);
    // Reset form fields
    setCustomerName('');
    setProductName('');
    setProductBrand('');
    setProduct('');
    setPFrom('');
    setPRate('');
    setPQty('');
    setPVehicle('');
    setToParty('');
    setToRate('');
    setToQty('');
    setPurchaseForm({ pFrom: "", pRate: "", pQty: "", pVehicle: "" });
    setToPartyEntries([]);
    setCurrentToParty({ selectedToParty: "", toRate: "", toQty: ""});
    setSelectedFromParty('');  // Reset From Party on closing modal
    setSelectedProduct('');
    setSelectedToParty('');
  };

  const handlePurchaseChange = (e) => {
    setPurchaseForm({ ...purchaseForm, [e.target.name]: e.target.value });
  };

  const handleToPartyChange = (e) => {
    debugger
    if(e.target.name == "toRate"){
      setToRate(e.target.value)
    }else if(e.target.name == "toQty"){
      setToQty(e.target.value)
    }
  };

  const addToPartyEntry = () => {
    if (
      selectedToParty &&
      currentToParty.toRate &&
      currentToParty.toQty     ) {
        debugger
      setToPartyEntries([...toPartyEntries, currentToParty]);
      setCurrentToParty({ selectedToParty:"", toRate: "", toQty: "" });
    } else {
      alert("Please fill out all fields in the To Party form before adding.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (modalType === 'PForm' || modalType === 'ToParty') {
      console.log('Customer Name:', customerName);
    } else if (modalType === 'ProductForm') {
      console.log('Product Name:', productName);
      console.log('Product Brand:', productBrand);
    } else if (modalType === 'Challan') {
      console.log('Product:', product);
      console.log('P From:', pFrom);
      console.log('Rate (P From):', pRate);
      console.log('Qty (P From):', pQty);
      console.log('Vehicle Number (P From):', pVehicle);
      console.log('To Party:', toParty);
      console.log('Rate (To Party):', toRate);
      console.log('Qty (To Party):', toQty);
    }
    const finalData = { purchaseForm, toPartyEntries };
    console.log("Submitted Data:", finalData);
    alert("Form submitted successfully!");
    closeModal();
  };

    // Handle product selection change
    const handleProductChange = (selectedOption) => {
      setSelectedProduct(selectedOption);  // Set selected product in state
      alert(selectedProduct.value)
    };  

      // Handle product selection change
      const handleFromPartyChange = (selectedOption) => {
        setSelectedFromParty(selectedOption); // Store the whole object, not just value
      };
      
      // Handle product selection change
      const handleToPartyDropdownChange = (selectedOption) => {
        setToParty(selectedOption)
        debugger
      };  

  return (
    <div className="App">
      <div className="button-container">
      <button onClick={() => openModal('Challan')}>Challan</button>
      <button onClick={() => openModal('PForm')}>P-Form</button>
      <button onClick={() => openModal('ToParty')}>To Party</button>
      <button onClick={() => openModal('ProductForm')}>Product Form</button>
    </div>
      <h2>Start editing to see some magic happen!</h2>

      {/* Modal */}
      {modalType && (
        <div className="modal">
        <div className="modal-content">
  <h3>
    {modalType === 'PForm' && 'P-Form Registration'}
    {modalType === 'ToParty' && 'To Party Registration'}
    {modalType === 'ProductForm' && 'Product Registration'}
    {modalType === 'Challan' && 'Challan'}
  </h3>

  <form onSubmit={handleSubmit} className="form-container">
    {/* Customer Name Form for P-Form and To Party */}
    {(modalType === 'PForm' || modalType === 'ToParty') && (
      <div className="form-group">
        <label>
          Customer Name:
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            required
            className="form-input"
          />
        </label>
      </div>
    )}

    {/* Product Form */}
    {modalType === 'ProductForm' && (
      <>
        <div className="form-group">
          <label>
            Product Name:
            <input
              type="text"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              required
              className="form-input"
            />
          </label>
        </div>
        <div className="form-group">
          <label>
            Product Brand:
            <input
              type="text"
              value={productBrand}
              onChange={(e) => setProductBrand(e.target.value)}
              required
              className="form-input"
            />
          </label>
        </div>
      </>
    )}

    {/* Challan Form */}
    {modalType === "Challan" && (
        <div className="modal">
          <div className="modal-content">
            <h3>Challan Form</h3>
            {/* <form onSubmit={handleSubmit}> */}
              {step === "purchase" && (
                <>
                  <h4>Purchase From</h4>
                  <div className="form-group">
                
                
                  <Select
  value={selectedProduct}
  onChange={handleProductChange}
  options={products.map(product => ({
    value: product.productId,
    label: product.productName
  }))}
  placeholder="Select a Product"
/>
              </div>
                  <div className="form-group">
              
                  <Select
  value={selectedFromParty} // Pass the entire object
  onChange={handleFromPartyChange}
  options={fromParties.map((party) => ({
    value: party.pfCustomerId,
    label: party.pfCustomerName
  }))}
  placeholder="Select a From Party"
/>

          
                  </div>
                  <div className="form-group">
                    <input
                      type="number"
                      name="pRate"
                      placeholder="Enter Rate"
                      step="0.01"
                      value={purchaseForm.pRate}
                      onChange={handlePurchaseChange}
                      required
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="number"
                      name="pQty"
                      placeholder="Enter Quantity"
                      value={purchaseForm.pQty}
                      onChange={handlePurchaseChange}
                      required
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      name="pVehicle"
                      placeholder="Enter Vehicle Number"
                      value={purchaseForm.pVehicle}
                      onChange={handlePurchaseChange}
                      required
                      className="form-input"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setStep("toParty")}
                    className="btn btn-next"
                  >
                    Next: To Party
                  </button>
                </>
              )}

              {step === "toParty" && (
                <>
                  <h4>To Party</h4>
                  <div className="form-group">
                  <Select
  value={toParty}
  onChange={handleToPartyDropdownChange}
  options={toParties.map(party => ({
    value: party.tpCustomerId,
    label: party.customerName
  }))}
  placeholder="Select a To Party"
/>

                  </div>
                  <div className="form-group">
                    <input
                      type="number"
                      name="toRate"
                      placeholder="Enter Rate"
                      step="0.01"
                      value={toRate}
                      onChange={handleToPartyChange}
                      required
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="number"
                      name="toQty"
                      placeholder="Enter Quantity"
                      value={toQty}
                      onChange={handleToPartyChange}
                      required
                      className="form-input"
                    />
                  </div>
              
                  <button
                    type="button"
                    onClick={addToPartyEntry}
                    className="btn btn-add"
                  >
                    Add To Party Entry
                  </button>

                  <h5>Added To Party Entries</h5>
                  <ul>
                    {toPartyEntries.map((entry, index) => (
                      <li key={index}>
                        {entry.selectedToParty.value}, {entry.toRate}, {entry.toQty}
                      </li>
                    ))}
                  </ul>
                  <div className="form-actions">
                    <button
                      type="button"
                      onClick={() => setStep("purchase")}
                      className="btn btn-back"
                    >
                      Back to Purchase
                    </button>
                    <button type="submit" className="btn btn-submit">
                      Submit Form
                    </button>
                    <button type="button" onClick={closeModal} className="btn btn-cancel">
        Cancel
      </button>
                  </div>
                </>
              )}
            {/* </form> */}
          </div>
        </div>
      )}


    {/* Modal Actions */}
    <div className="modal-actions">
      <button type="submit" className="btn btn-submit">
        Submit
      </button>
      <button type="button" onClick={closeModal} className="btn btn-cancel">
        Cancel
      </button>
    </div>
  </form>
</div>

        </div>
      )}
    </div>
  );
}
